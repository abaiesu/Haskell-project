This is the CSE301 Project for Antonia Baies and Aarrya Saraf.
The only non standard import is for colors of lines in the terminals.
The project is run by the following command: ":l Game.hs" followed by "main"
after that the game is sel contained and will guide you through the steps!
The Game.hs file is the main file. its job is to run the actual game and call in the required
elements from the other files
the Printing.hs file as the name suggests is used to print the Farm
the Parser.hs as the name suggests is used to parse the input
along with the given go left and go right we also can use just left or just right for eg
the Cmd.hs file is a small file with just the data types of the commands for our parser
Finally the Bin.Hs file is the backbone. This is where all the calculatins and magic take place.